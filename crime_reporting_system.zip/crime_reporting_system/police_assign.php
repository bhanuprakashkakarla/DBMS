<!DOCTYPE html>
<html>
<head>
	<title>Complainer Home Page</title>

	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

	<link href="complainer_page.css" rel="stylesheet" type="text/css" media="all" />
	<?php
    session_start();
    if(!isset($_SESSION['x']))
        header("location:inchargelogin.php");
    
    $con=mysqli_connect('localhost','root','','crime_portal');
    if(!$con)
    {
        die('could not connect: '.mysqli_error());
    }
     mysqli_select_db($con,"crime_portal");
    
    $i_id=$_SESSION['email'];

    $result1=mysqli_query($con,"SELECT location FROM police_station where i_id='$i_id'");
      
    $q2=mysqli_fetch_assoc($result1);
    $location=$q2['location'];
    
if(isset($_POST['s'])){
    
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $c_id=$_POST['compliant_id'];
        $p_id=$_POST['police_id'];


    $reg="UPDATE COMPLAINT SET POLICE_ID='$p_id',COMPLAINT_STATUS='assigned' WHERE c_id='$c_id'";
    
    if (mysqli_query($con, $reg)) {
      echo "Record updated successfully";
    } else {
      echo "Error updating record: " . mysqli_error($con);
    }
    }
}
?>
    
     <script>
     function f1()
    {
      var sta1=document.getElementById("pid").value;
      var sta2=document.getElementById("pid").value;
      var x1=sta1.indexOf(' ');
      var x2=sta2.indexOf(' ');
  if(sta1!="" && x1==""){
    document.getElementById("cid").value="";
    document.getElementById("cid").focus();
      alert("Space Not Allowed");
        }
        
         else if(sta2!="" && x2>=0){
    document.getElementById("pid").value="";
    document.getElementById("pid").focus();
      alert("Space Not Allowed");
        }      
}
</script>
</head>

<body style="background-size: cover;
    background-image: url(home_bg1.jpeg);
    background-position: center;">
	<nav  class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="home.php"><b>Home</b></a>
    </div>
    <div id="navbar" class="collapse navbar-collapse">
      <ul class="nav navbar-nav">
        <li ><a href="official_login.php">Official Login</a></li>
        <li><a href="incharge_view_police.php">Incharge Home</a></li>
      </ul>
     
      <ul class="nav navbar-nav navbar-right">
        <li ><a href="police_add.php">Log Police Officer</a></li>
        <li class="active"><a href="police_assign.php">police assigning</a></li>
        <li><a href="Incharge_complain_page.php">Complaint History</a></li>
        <li><a href="inc_logout.php">Logout &nbsp <i class="fa fa-sign-out" aria-hidden="true"></i></a></li>
      </ul>
    </div>
  </div>
 </nav>
<div class="video" style="margin-top: 5%"> 
	<div class="center-container">
		 <div class="bg-agile">
			<br><br>
			<div class="login-form"><p><h2>Log Police Officer</h2></p><br>	
				<form action="#" method="post" style="color: gray">Compliant Id
					<input type="text"  name="compliant_id" placeholder="compliant id" required="" id="cid" onfocusout="f1()"/>
					Police Id<input type="text"  name="police_id" placeholder="Police Id" required="" id="pid" onfocusout="f1()"/>
          <br>
					<input type="submit" value="Submit" name="s">

			</div>	
		</div>
	</div>	
</div>	
 <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.js"></script>
 <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>
</html>